# VideoGameDatabase
Designed by Jonathan Bahm and Tristan Chilvers. <br/>
There is also a PNG of the schema to help visualize the database 

## Running
To run, compile the dbInterface.py via python. There will be a text-interface to run various SQLite commands.<br/>
There is also a small generated database with a few records inputted.
